package com.example.datavirus;

public interface OnChartElementActions {

    public void onChartElementActions();

}
