package com.example.datavirus;

public interface OnTileClick {

    public void onTileClick(FieldGeographicElement fieldGeographicElement);
}
